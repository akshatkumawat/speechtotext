export const ACTIONS = {
  SET_PAUSE: 'set_pause',
  SET_TERM: 'set_term',
  SET_LOADING: 'set_loading',
  SET_CURRENT_INDEX: 'set_current_index',
  SET_VIDEO_LIST: 'set_video_list',
  SET_TIMER_TIME: 'set_timer_time',
};
