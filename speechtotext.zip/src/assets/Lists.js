export const dogList = [require('./dog1.mp4'), require('./dog2.mp4')];
export const catList = [require('./cat1.mp4'), require('./cat2.mp4')];
